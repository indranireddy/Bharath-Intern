document.getElementById('weatherForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const city = document.getElementById('cityInput').value;
    const apiKey = '6e674840471d3553659c195e14284bda'; // Replace with your OpenWeatherMap API key
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                document.getElementById('weatherResult').style.display = 'block';
                document.getElementById('cityName').textContent = `${data.name}, ${data.sys.country}`;
                document.getElementById('temperature').textContent = `Temperature: ${data.main.temp} °C`;
                document.getElementById('description').textContent = `Weather: ${data.weather[0].description}`;
                document.getElementById('humidity').textContent = `Humidity: ${data.main.humidity}%`;
                document.getElementById('wind').textContent = `Wind: ${data.wind.speed} km/h`;
                document.getElementById('pressure').textContent = `Pressure: ${data.main.pressure} mb`;
                document.getElementById('precipitation').textContent = `Precipitation: ${data.rain ? data.rain['1h'] : 0} mm`;

                const icon = data.weather[0].icon;
                const iconUrl = `http://openweathermap.org/img/wn/${icon}@2x.png`;
                document.getElementById('weatherIcon').src = iconUrl;
                document.getElementById('weatherIcon').style.display = 'block';

                fetchForecast(city, apiKey);
            } else {
                alert('City not found');
            }
        })
        .catch(error => {
            console.error('Error fetching weather data:', error);
            alert('Error fetching weather data');
        });
});

function fetchForecast(city, apiKey) {
    const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=metric`;

    fetch(forecastUrl)
        .then(response => response.json())
        .then(data => {
            const forecast = data.list.filter(item => item.dt_txt.endsWith("12:00:00"));

            for (let i = 0; i < 5; i++) {
                const dayElement = document.getElementById(`day${i + 1}`);
                const date = new Date(forecast[i].dt_txt).toLocaleDateString('en-US', { weekday: 'short' });
                const icon = forecast[i].weather[0].icon;
                const iconUrl = `http://openweathermap.org/img/wn/${icon}.png`;

                dayElement.innerHTML = `
                    <p>${date}</p>
                    <img src="${iconUrl}" alt="Weather Icon">
                    <p>${forecast[i].main.temp} °C</p>
                `;
            }
        })
        .catch(error => {
            console.error('Error fetching forecast data:', error);
            alert('Error fetching forecast data');
        });
}
